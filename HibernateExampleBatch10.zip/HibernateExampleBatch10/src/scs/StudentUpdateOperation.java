package scs;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StudentUpdateOperation {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hiber.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		int rno=1001;
		Student st = (Student) s.load(Student.class,rno);
		Transaction tx = s.beginTransaction();
		st.setSname("manish");
		st.setBranch("CS");
		st.setFees(4500);
		s.save(st);
		tx.commit();
		s.close();
		sf.close();


	}

}
