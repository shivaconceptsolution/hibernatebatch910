package scs;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class StudentDeleteOperation {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hiber.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		int rno=1001;
		Student st = (Student) s.load(Student.class,rno);
		Transaction tx = s.beginTransaction();
		s.delete(st);
		tx.commit();
		s.close();
		sf.close();

	}

}
