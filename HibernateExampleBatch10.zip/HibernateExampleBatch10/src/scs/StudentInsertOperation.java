package scs;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class StudentInsertOperation {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hiber.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Student obj = new Student();
		obj.setRno(1002);
		obj.setSname("xyz");
		obj.setBranch("CS");
		obj.setFees(12000);
		Transaction tx = s.beginTransaction();
		s.save(obj);
		tx.commit();
		s.close();
		sf.close();
		
		

	}

}
